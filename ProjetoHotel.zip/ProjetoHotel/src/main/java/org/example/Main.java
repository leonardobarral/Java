package org.example;
import org.example.UIL.PessoaController;
import org.example.UIL.QuartoController;
import org.example.UIL.ReservaController;

import java.io.Console;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class Main {
    static final List<Pessoa> pessoas = new ArrayList();
    static PessoaController pessoaController;
    static QuartoController quartoController;
    static ReservaController reservaController;




    public static void main(String[] args) {
        System.out.println("Bem vindo ao sistema do Hotel Paradise!\r\n");
        Scanner scanner = new Scanner(System.in);
        pessoaController = new PessoaController(scanner);
        quartoController = new QuartoController(scanner);
        reservaController = new ReservaController(scanner);
        MenuPrincipal(scanner);
    }

    public static void ListarPessoas()
    {
        for (var pessoa:pessoas) {
            System.out.println(pessoa.toString());
        }
    }
    public static void MenuPrincipal(Scanner scanner)
    {
        System.out.println("""
                Selecione a opção desejada:\s
                1. Cadastro de pessoas                                
                2. Cadastro de quartos                                
                3. Reserva de quarto                                
                5. Listar pessoas                                
                6. Listar quartos                                
                0. Sair do sistema                
                """);
        var opcao = 0;
        while (opcao == 0) {
            try {
                var textoOpcao = scanner.next();
                opcao = Integer.parseInt(textoOpcao);
            } catch (Exception e) {
                System.out.println("Opção inválida, tente novamente!");
            }
        }
        while (opcao != 0) {
            switch (opcao) {
                case 1 -> pessoaController.IniciarFormularioCadastroDePessoas();
                case 2 -> quartoController.IniciarFormularioCadastroDeQuartos();
                case 3 -> reservaController.IniciarFormularioCadastroDeReserva();
                case 5 -> ListarPessoas();
            }
            MenuPrincipal(scanner);
            opcao = scanner.nextInt();
        }
        System.exit(0);
    }}