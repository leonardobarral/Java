package org.example;

public class Quarto {
}
