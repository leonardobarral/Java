package org.example.BLL;

import java.util.Collection;
import java.util.List;

public interface IService<T> {
    public void Inserir(T item);
    public void Update(T item);
    public void Remove(T item);
    public List<T> GetALL();

}