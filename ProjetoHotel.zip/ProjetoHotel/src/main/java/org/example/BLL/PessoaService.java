package org.example.BLL;

import org.example.Pessoa;

import java.util.List;

public class PessoaService implements IService<Pessoa> {
    @Override
    public void Inserir(Pessoa item) {

    }

    @Override
    public void Update(Pessoa item) {

    }

    @Override
    public void Remove(Pessoa item) {

    }

    @Override
    public List<Pessoa> GetALL() {
        return null;
    }
}
