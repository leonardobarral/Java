package org.example.BLL;


import org.example.Pessoa;
import org.example.Reserva;

import java.util.List;

public class ReservaService implements IService<Reserva>{


    @Override
    public void Inserir(Reserva item) {

    }

    @Override
    public void Update(Reserva item) {

    }

    @Override
    public void Remove(Reserva item) {

    }

    @Override
    public List<Reserva> GetALL() {
        return null;
    }
}

