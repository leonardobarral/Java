package org.example.BLL;

import org.example.Quarto;

import java.util.List;

public class QuartoService implements IService<Quarto>{
    @Override
    public void Inserir(Quarto item) {

    }

    @Override
    public void Update(Quarto item) {

    }

    @Override
    public void Remove(Quarto item) {

    }

    @Override
    public List<Quarto> GetALL() {
        return null;
    }
}
