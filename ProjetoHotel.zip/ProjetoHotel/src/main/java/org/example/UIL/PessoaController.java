package org.example.UIL;

import org.example.BLL.IService;
import org.example.BLL.PessoaService;
import org.example.Pessoa;

import java.util.Scanner;

public class PessoaController {

    IService<Pessoa> PessoaService = new PessoaService();
    private Scanner scanner;

    public PessoaController(Scanner scanner) {
        this.scanner = scanner;
    }

    public Scanner getScanner() {
        return scanner;
    }

    public void setScanner(Scanner scanner) {
        this.scanner = scanner;
    }

    public void IniciarFormularioCadastroDePessoas(){
        System.out.println("Primeiro, digite o nome da pessoa");
        var nome = scanner.next();
        System.out.println("Primeiro, digite o CPF da pessoa");
        var cpf = scanner.next();
        new Pessoa(nome, cpf);
        System.out.println("Cadastro realizado: nome: "+nome+" cpf: "+cpf);
    }
}
