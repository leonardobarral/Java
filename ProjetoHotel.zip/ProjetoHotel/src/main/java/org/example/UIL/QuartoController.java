package org.example.UIL;

import org.example.Pessoa;

import java.util.Scanner;

public class QuartoController {

    private Scanner scanner;

    public QuartoController(Scanner scanner) {
        this.scanner = scanner;
    }

    public void IniciarFormularioCadastroDeQuartos(){
        System.out.println("Primeiro, digite o número do quarto");
        var numero = scanner.next();
        System.out.println("Primeiro, digite o tipo de quarto");
        var tipo = scanner.next();
        System.out.println("Cadastro realizado: Número: "+numero+" Tipo: "+tipo);
    }

}
