package org.example.UIL;

import java.util.Scanner;

public class ReservaController {

    private Scanner scanner;

    public Scanner getScanner() {
        return scanner;
    }

    public void setScanner(Scanner scanner) {
        this.scanner = scanner;
    }

    public ReservaController(Scanner scanner) {
        this.scanner = scanner;
    }

    public void IniciarFormularioCadastroDeReserva(){
        System.out.println("Primeiro, digite a data da reserva");
        var data = scanner.nextLine();
        System.out.println("Primeiro, digite o tipo de quarto");
        var nome = scanner.nextLine();
        System.out.println("Cadastro realizado: data: "+data+" data: "+nome);
    }
}
